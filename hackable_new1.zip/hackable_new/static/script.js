//Using our API

function setCookie(name, value, days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + value + expires + "; path=/";
}

// Add a function to get a cookie value
function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) === ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

$(document).ready(function () {
    // Initial check for the firewall status
    updateFirewallStatus();

    // Toggle switch change event
    $('#firewallToggle').change(function () {
        var enabled = this.checked;

        // Update the firewall status on the server
        updateFirewallStatusOnServer(enabled);

        // Update the firewall status text
        updateFirewallStatusText(enabled);
    });
});

function updateFirewallStatus() {
    // Fetch the firewall status from the server or any other source
    // You may use an AJAX request to get the status from the server
    var firewallEnabled = true; // Replace with the actual status

    // Update the toggle switch
    $('#firewallToggle').prop('checked', firewallEnabled);

    // Update the status text
    updateFirewallStatusText(firewallEnabled);
}

function updateFirewallStatusOnServer(enabled) {
    // Perform an AJAX request to update the firewall status on the server
    // You may need to adjust the URL and method based on your server implementation
    $.ajax('/api/v1.0/updateFirewallStatus', {
        method: 'POST',
        data: JSON.stringify({ 'enabled': enabled }),
        dataType: "json",
        contentType: "application/json",
    }).done(function (res) {
        console.log('Firewall status updated on the server');
    }).fail(function (err) {
        console.error('Error updating firewall status:', err.statusText);
    });
}

function updateFirewallStatusText(enabled) {
    // Get the switch button and the associated label
    var switchBtn = $('#firewallToggle');
    var switchLabel = switchBtn.closest('label');

    // Get the span element inside the label (the slider text)
    var sliderText = switchLabel.find('.slider-text');

    // Update the text based on the firewall state
    if (enabled) {
        sliderText.text('Firewall Enabled');
    } else {
        sliderText.text('Firewall Disabled');
    }
}

// Add a function to check the cookie and fill in the username if present
function checkRememberMe() {
    var storedUsername = getCookie("rememberedUsername");
    if (storedUsername) {
        document.getElementById("uname").value = storedUsername;
        document.getElementById("rememberMe").checked = true;
    }
}

checkRememberMe();

function handleSearchError(err) {
    // Check if the error message indicates a security scan failure
    if (err.responseJSON && err.responseJSON.status === 'fail' && err.responseJSON.message === 'Security scan failed') {
        $("#stat").html("Security scan failed: " + err.responseJSON.message);
    } else {
        // Display the standard error message for other errors
        $("#stat").html("Error: " + err.statusText);
    }
}

function displayResults(results) {
    // Clear previous results
    $("#results").empty();

    // Check if the response indicates a security scan failure
    if (results.status && results.status === 'fail') {
        $("#stat").html(results.message);
        return;
    }

    // Check if any results are returned
    if (results.length > 0) {
        // Append table headers
        var headers = "<tr><th>Name</th><th>Quantity</th><th>Price</th></tr>";
        $("#results").append(headers);

        // Append each result to the table
        $(results).each(function () {
            var row = "<tr><td>" + this['name'] + "</td>";
            row += "<td>" + this['quantity'] + "</td>";
            row += "<td>" + this['price'] + "</td></tr>";
            $("#results").append(row);
        });

        // Update the status message
        $("#stat").html("");
    } else {
        // Update the status message if no results are found
        $("#stat").html("No results found.");
    }
}

function login() {
    var uname = document.getElementById("uname").value;
    var passw = document.getElementById("passw").value;
    var rememberMe = document.getElementById("rememberMe").checked;

    var dat = { 'username': uname, 'password': passw };

    $.ajax('/api/v1.0/storeLoginAPI/', {
        method: 'POST',
        data: JSON.stringify(dat),
        dataType: "json",
        contentType: "application/json",
    }).done(function (res) {
        if (res['status'] === 'success') {
            $("#stat").html('<b>Successful Login<b>');

            // Redirect using JavaScript
            window.location.href = res['redirect'];

            // Remember Me logic
            if (rememberMe) {
                setCookie("rememberedUsername", uname, 30); // Cookie expires in 30 days
            } else {
                // If Remember Me is not checked, clear the cookie
                setCookie("rememberedUsername", "", -1); // Expire the cookie immediately
            }
        } else if (res['status'] === 'fail' && res['message'] === 'Security scan failed') {
            // Update the status message for security scan failure
            $("#stat").html('<b>Login Failed</b>: ' + res['message']);
        } else if (res['status'] === 'fail' && res['message'] === 'Invalid credentials') {
            // Update the status message for invalid credentials
            $("#stat").html('<b>Login Failed</b>: ' + res['message']);
        } else if (res['status'] === 'fail' && res['message'] === 'Firewall is disabled. Scan cannot be initiated.') {
            // Update the status message for firewall disabled
            $("#stat").html('<b>Login Failed</b>: ' + res['message']);
        } else {
            // Update the status message for other login failures
            $("#stat").html('<b>Login Failed</b>');
        }
    }).fail(function (err) {
        // Handle other errors, if any
        $("#stat").html("Error: " + err.statusText);
    });
}

function search() {
    var item = document.getElementById("searchItem").value.trim();

    if (item === "") {
        // If the search input is empty, fetch all items
        $.ajax('/api/v1.0/storeAPI', {
            method: 'GET',
        }).done(function (res) {
            displayResults(res);
        }).fail(function (err) {
            handleSearchError(err);
        });
    } else {
        // If the search input is not empty, perform the search with a query parameter
        $.ajax('/api/v1.0/storeAPI?item=' + encodeURIComponent(item), {
            method: 'GET',
        }).done(function (res) {
            if (res['status'] === 'fail' && res['message'] === 'Firewall is disabled. Scan cannot be initiated.') {
                // Update the status message for firewall disabled
                $("#stat").html('<b>Search Failed</b>: ' + res['message']);
            } else {
                displayResults(res);
            }
        }).fail(function (err) {
            handleSearchError(err);
        });
    }
}

function addItem() {
    var name = document.getElementById("itemName").value;
    var quan = document.getElementById("itemQuantity").value;
    var price = document.getElementById("itemPrice").value;

    var dat = {'name': name, 'quantity': quan, 'price': price};

    $.ajax('/api/v1.0/storeAPI', {
        method: 'POST',
        data: JSON.stringify(dat),
        dataType: "json",
        contentType: "application/json",
    }).done(function (res) {
        if (res['status'] === 'fail' && res['message'] === 'Firewall is disabled. Scan cannot be initiated.') {
            // Update the status message for firewall disabled
            $("#stat").html('<b>Add Item Failed</b>: ' + res['message']);
        } else {
            $("#stat").html(res.message);
        }
    }).fail(function (err) {
        console.error("Error sending request:", err.statusText);
        $("#stat").html("Error Sending Request");
    });
}

// Logout function
function logout() {
    // Perform any additional logout actions if needed

    // Redirect to the Flask login route
    $.ajax('/logout', {
        method: 'GET',
        dataType: "json",
        contentType: "application/json",
    }).done(function (res) {
        // Redirect to the Flask login route
        window.location.href = '{{ url_for("login") }}';
    }).fail(function (err) {
        console.error(err);
        // Redirect to the Flask login route even if the logout API call fails
        window.location.href = '{{ url_for("login") }}';
    });
}


$(document).ready(function(){

    $("#navbar ul li a").on('click', function(event){
        event.preventDefault();
        var page = $(this).attr("href");

        // Check if the page has a hash, and update the window location accordingly
        if (page.startsWith("#")) {
            window.location.hash = page;
        } else {
            // Load the content using AJAX
            $("#main").load(page);
        }
    });

    // Check the initial hash and load the corresponding content
    if (window.location.hash) {
        $("#main").load(window.location.hash.slice(1));
    }
});
