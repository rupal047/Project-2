SELECT ?,?,? FROM ? WHERE name='juice';
