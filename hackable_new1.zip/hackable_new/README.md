# hackable
A python flask app that is purposfully vulnerable to SQL injection and XSS attacks

# How to run
Just `cd` into the hackable folder and type into the termnial `python main.py`

# Notes
* test.sql is just there to help to visualize what is happening with sql queries during the demo
* Commands For Sqlite Hack.txt is there to show the sql statements used during the demo and explain them
* The search page is vulnerable to SQL injections
* The add items page is vulnerable to XSS
* The login page is also vulnerable to SQL injection making it easy to bypass login
